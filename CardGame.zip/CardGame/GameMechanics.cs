﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CardGame
{
    public class GameMechanics
    {
        public void AttackProcess(Entity sourceEntity, Entity targetEntity)
        {
                int sourceEntityModAttack = sourceEntity.attack + AttackModifier(targetEntity);
                int targetEntityModAttack = targetEntity.attack + AttackModifier(sourceEntity);
                Console.WriteLine(sourceEntity.entityId + " attacks " + targetEntity.entityId + ".");
                Console.ReadKey();
                targetEntity.health = targetEntity.health - sourceEntityModAttack;
                sourceEntity.health = sourceEntity.health - targetEntityModAttack;

                if (sourceEntity.health <= 0 && targetEntity.health <= 0)
                {
                    Console.WriteLine(sourceEntity.entityId + " attacked " + targetEntity.entityId + " for " + sourceEntityModAttack + " damage and it died.");
                    Console.WriteLine(targetEntity.entityId + " retaliated " + targetEntityModAttack + " damage to " + sourceEntity.entityId + " and it died.");
                }
                if (sourceEntity.health <= 0 && targetEntity.health > 0)
                {
                    Console.WriteLine(sourceEntity.entityId + " attacked " + targetEntity.entityId + " for " + sourceEntityModAttack + " damage. It now has " + targetEntity.health + " HP.");
                    Console.WriteLine(targetEntity.entityId + " retaliated " + targetEntityModAttack + " damage to " + sourceEntity.entityId + " and it died.");
                }
                if (sourceEntity.health > 0 && targetEntity.health <= 0)
                {
                    Console.WriteLine(sourceEntity.entityId + " attacked " + targetEntity.entityId + " for " + sourceEntityModAttack + " damage and it died.");
                    Console.WriteLine(targetEntity.entityId + " retaliated " + targetEntityModAttack + " damage to " + sourceEntity.entityId + ". It now has " + sourceEntity.health + " HP.");
                }
                if (sourceEntity.health > 0 && targetEntity.health > 0)
                {
                    Console.WriteLine(sourceEntity.entityId + " attacked " + targetEntity.entityId + " for " + sourceEntityModAttack + " damage. It now has " + targetEntity.health + " HP.");
                    Console.WriteLine(targetEntity.entityId + " retaliated " + targetEntityModAttack + " damage to " + sourceEntity.entityId + ". It now has " + sourceEntity.health + " HP.");
                }

            Console.ReadKey();
            sourceEntity.attackReady = false;
        }

        public bool AttackCheck(Entity sourceEntity, Entity targetEntity)
        {
            if (sourceEntity.entityId == targetEntity.entityId)
            {
                Console.Clear();
                Console.WriteLine("Error : Entity cant attack itself.");
                Console.WriteLine("Press any key to return...");
                Console.ReadKey();
                return false;

            }

            else if (sourceEntity.entityType == EntityType.Creature && targetEntity.entityType == EntityType.Avatar)
            {
                Console.WriteLine("Error: Creature can't attack avatar.");
                Console.WriteLine("Press any key to return...");
                Console.ReadKey();
                return false;
            }

            else if (sourceEntity.attackReady == false)
            {
                Console.WriteLine("Error: Attacking entity already attacked.");
                Console.WriteLine("Press any key to return...");
                Console.ReadKey();
                return false;
            }

            return true;
           
        }



        public static void AttackReset()
        {
            Root.LiveEntities.ForEach(e => e.attackReady = true);
        }


        public static int AttackModifier(Entity entity)
        {
            int result = 0;
            foreach(var modifier in entity.modifiers)
            {
                int midResult = 0;
                if(modifier.modifierType == ModifierType.Armour)
                {
                    midResult -= modifier.value;
                }

                if(modifier.modifierType == ModifierType.Vulnerability)
                {
                    midResult += modifier.value;
                }

                result = midResult;
            }
           

            return result;
            
        }
        //public string[] SourceId()
        //{
        //    string[] sourceId = {""};
        //    for(int i = 0; i <= Root.Entities.Count; i++)
        //    {
        //        sourceId[i] = Root.Entities[i].entityId;
        //    }
        //    return sourceId;

        //}


        /*- Ulazni parametri u sustav za jedan napad su sourceId i targetId. -DONE
        - U board.json su spremljeni entiteti koji su aktivni na "boardu". - DONE
        - Entitet može biti iz 2 vrste: 1 - Creature, 2 - Avatar. - DONE
        - Aplikacija treba biti spremna za dodavanje novih vrsta entiteta. -DONE
        - Creature ne može napasti avatara, avatar može napasti creatura. - DONE
        - Entitet ne može napasti ako nije attackReady. -DONE
        - Ako creature pokuša napasti avatara ili entitet nije attackReady, vratiti odgovarajuću poruku.-DONE
        - Mrtvi entiteti ne mogu napadati, niti biti napadnuti.-DONE
        - Nakon napada, health od targeta mora se umanjiti za sourceov attack atribut. - DONE
        - Target vraća damage napadaću sa vrijednosti svog Attack atributa (Retaliate).- DONE
        - Može imati i listu modifiera: 1 - Armour i 2 - Vulnerability. - DONE
        - Armour modifier umanjuje damage napada za određen value, vulnerability povećava damage koji će entitet primiti. -DONE
        - Aplikacija treba biti spremna za nove vrste modifiera koji promjenu vrijednosti napada računaju kao funkciju (npr povećanje napada za x%, povećanje za X puta, itd). -TBD
        - Value je vrijednost modifiera. Npr. ako je modifierType 1 i value 2 onda će se na tom creaturu na kojem je modifier spustiti svaki primljeni damage za 2. - DONE
        - Nakon napada:
        - attackReady se mora prebaciti na false napadaću. -DONE
        - sustav mora spremiti novo stanje entiteta u board.json i vratiti EntityAttackedMessage(na konzolu) sa sljedećim poljima : sourceId, targetId i value. -TBD
        - Napadi se simuliraju u rundama, svaki entitet može (ali ne mora) napasti jednom po rundi. - DONE
        - Završetak runde treba biti moguć u svakom trenutku. - DONE
        - Na prijelazu između rundi svim entitetima AttackReady resetira se na true. -DONE
        - Općenito zadatak treba riješiti kao da će biti dio večeg sustava na serveru. -NIŠTA
        - pokažite svoju vještinu, koristite sve dobre prakse u programiranju, oblikovne obrasce, apstrakciju, ...
        board.json
        */

    }
}
